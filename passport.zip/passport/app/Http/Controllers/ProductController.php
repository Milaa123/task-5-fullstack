<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
    public function index()
    {
        $product = auth()->user()->products;

        return response()->json([
            'success' => true,
            'data' => $product

       ], 400);
    }
    public function show($id)
    {
        $products = auth()->user()->products()->find($id);

        if (!$products) {
            return response()->json([
                'success' => false,
                'data' => 'Product with id' . $id . 'not found',

            ], 400);
        }
        return response()->json([
            'success' => true,
            'data' => $products->toArray(),
        ], 400);
    }
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'price' => 'required|integer',
        ], );
        $product = new Product();
        $product->name = $request->name;
        $product->price = $request->price;

        if (auth()->user()->products()->save($product)) {
            return response()->json([
                'success' => true,
                 'data' => $product->toArray(),
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                 'data' => 'Product Not Found',
            ], 500);
        }
    }
    public function update(Request $request, $id)
    {
        $product = auth()->user()->products()->find($id);

        if (!$product) {
            return response() ->json([
                'success' => false,
                 'data' => 'Product with id' . $id. 'not found',
            ], 500);
        }

        $update = $product->fill($request->all())->save();

        if ($update) {
            return response()->json([
                'success' => true,
                'data' => 'Product updated',
            ], 200);
        } else {
            return response()->json([
                'success' => false,
                'data' => 'Product not updated',
            ], 500);
        }
    }

    public function destroy($id)
    {
        $product = auth()->user()->products()->find($id);
        if ($product) {
            return response()->json([
                'success' => false,
                'massage' => 'Product with id'. $id. 'not found',
            ], 400);
        }

        if($product->delete()){
            return response()->json([
                'success' => true,
                'massage' => 'Product deleted',
            ],);
        }
        else {
            return response()->json([
                'success' => false,
                'data' => 'Product not updated',
            ], 500);
        }
    }
}